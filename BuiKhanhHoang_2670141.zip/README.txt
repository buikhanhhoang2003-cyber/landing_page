KALMAN FILTER HOMEWORK - Chapter 6
Student: Bui Khanh Hoang (Bùi Khánh Hoàng)
ID: 2670141

Files:
  homework_kalman_2670141.tex   LaTeX report with derivations and five figures
  homework_kalman_2670141.pdf   Compiled, verified 10-page PDF report
  kalman_homework_2670141.py   Completed seed-locked Python starter code
  numerical_results.json       Exported seed-locked outputs
  simulation_log.txt           Console results of Python execution
  figures/figure_1.png         Example 3 convergence: white vs colored input
  figures/figure_2.png         Example 4 tracking: tap 1 and tap 5
  figures/figure_3.png         Sudden system change: standard vs tracking
  figures/figure_4.png         Adaptive covariance resetting
  figures/figure_5.png         Uniform-noise Chebyshev bounds

Requirements:
  Python 3, numpy, matplotlib
  XeLaTeX; fonts Noto Serif, Noto Sans, DejaVu Sans Mono

Run from the directory containing the .tex and .py files:
  python kalman_homework_2670141.py
  xelatex -interaction=nonstopmode homework_kalman_2670141.tex
  xelatex -interaction=nonstopmode homework_kalman_2670141.tex

The 5 figures display the student's accented name and ID.
For c, the peak is maximum absolute value of the 3rd coefficient; the signed
peak is -1.198882372534 at n=77.
For d, the first 10-consecutive-sample in-bound run starts at n=1002 and is
confirmed at n=1011.
For f, bounds use R_pre before the covariance reset.

Implementation conventions, also stated in the report:
 - For n=1, use the first M generated input samples in reverse order;
   the first M-1 samples represent pre-history.
 - Example 4's random-walk true weights start at h(1)=h0 and add b for n>=2.
 - Question d uses Example 4 Q1=0.01I with the Example 3 measurement noise
   variance Q2=0.12, as explicitly required in the exercise.
