# =========================================================================
# STARTER CODE TEMPLATE: HOMEWORK - CHAPTER 6 (KALMAN FILTER)
# Course: Advanced Digital Signal Processing
# Student: Bui Khanh Hoang (accented name is used below)
# =========================================================================
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

# -------------------------------------------------------------------------
# 1. STUDENT INFORMATION & PERSONALIZED PARAMETERS
# -------------------------------------------------------------------------
Student_Name = "Bùi Khánh Hoàng"
Student_ID = 2670141

k0 = Student_ID % 10
k1 = (Student_ID // 10) % 10
k2 = (Student_ID // 100) % 10

print(f"Student: {Student_Name} (ID: {Student_ID}) -> k0={k0}, k1={k1}, k2={k2}")

M = 5
h0_5 = np.array([1.0 + 0.1 * k0, 0.5, -1.0, 0.3, -0.4 - 0.05 * k1])
Q2_ex3 = 0.10 + 0.02 * k2
Q2_ex4 = 1.00 + 0.10 * k2
Q1_ex4 = 0.01 * np.eye(M)

OUTPUT_DIR = Path(__file__).resolve().parent
FIGURE_DIR = OUTPUT_DIR / "figures"
FIGURE_DIR.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.labelsize": 10,
    "axes.titlesize": 11,
    "figure.titlesize": 15,
    "legend.fontsize": 9,
    "savefig.dpi": 180,
})
COLORS = plt.cm.tab10(np.arange(M))


def input_vectors(signal, samples, taps):
    """Create U[n] = [u(n), ..., u(n-M+1)] for n = 1,...,N."""
    # The first M-1 samples are pre-history. Cycle n=1 uses samples M-1..0.
    current = np.arange(taps - 1, taps - 1 + samples)[:, None]
    lags = np.arange(taps)[None, :]
    return signal[current - lags]


def simulate_kalman(U, desired, Q2, Q1, adaptive=False):
    """Kalman identification with F=I; optionally reset P to I on outliers."""
    cycles, taps = U.shape
    h = np.zeros(taps)
    P = np.eye(taps)
    states = np.zeros((cycles, taps))
    innovations = np.zeros(cycles)
    R_pre = np.zeros(cycles)
    R_used = np.zeros(cycles)
    trace_prior = np.zeros(cycles)
    trace_pre = np.zeros(cycles)
    trace_filt = np.zeros(cycles)
    reset_flags = np.zeros(cycles, dtype=bool)
    q1 = np.asarray(Q1)

    for i in range(cycles):
        u = U[i]
        alpha = float(desired[i] - u @ h)
        r_before = float(u @ P @ u + Q2)
        trace_pre[i] = np.trace(P)
        innovations[i] = alpha
        R_pre[i] = r_before

        if adaptive and abs(alpha) > 2.0 * np.sqrt(r_before):
            P = np.eye(taps)
            reset_flags[i] = True

        trace_prior[i] = np.trace(P)  # effective prior, AFTER optional reset
        R = float(u @ P @ u + Q2)
        G = (P @ u) / R
        states[i] = h = h + G * alpha
        P = P - np.outer(G, u @ P)
        P = 0.5 * (P + P.T)  # remove floating point asymmetry only
        trace_filt[i] = np.trace(P)
        P = P + q1  # prediction to cycle n+1, F=I
        R_used[i] = R

    return {
        "h_hat": states,
        "alpha": innovations,
        "R_pre": R_pre,
        "R_used": R_used,
        "trace_pre": trace_pre,
        "trace_prior": trace_prior,
        "trace_filt": trace_filt,
        "resets": reset_flags,
    }


def add_event_line(ax, idx=1001):
    ax.axvline(idx, color="black", lw=1.1, ls=":", alpha=0.75)
    ax.grid(alpha=0.22)


def save_figure(fig, index):
    path = FIGURE_DIR / f"figure_{index}.png"
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def weight_comparison(ax, n, true_weights, estimates, show_legend=True):
    """Plot 5 true weights and labeled estimates on one panel."""
    for j in range(M):
        ax.plot(n, true_weights[:, j], color=COLORS[j], ls=":", alpha=0.45, lw=1.1)
        for label, data, ls in estimates:
            ax.plot(n, data[:, j], color=COLORS[j], ls=ls, lw=1.05,
                    alpha=0.80 if ls == "--" else 0.95)
    if show_legend:
        handles = [Line2D([0], [0], color=COLORS[j], lw=2, label=f"Tap {j+1}")
                   for j in range(M)]
        handles += [Line2D([0], [0], color="#444444", ls=":", lw=2, label="True")]
        handles += [Line2D([0], [0], color="#444444", ls=ls, lw=2, label=label)
                    for label, _, ls in estimates]
        ax.legend(handles=handles, loc="upper center", ncol=4, fontsize=8,
                  framealpha=0.93)
    ax.set_ylabel("Tap value")
    ax.grid(alpha=0.22)


# =========================================================================
# QUESTION b): 2-Tap (M = 2) Hand-Calculation Verification (n = 1, 2, 3)
# =========================================================================
h_true_2 = np.array([1.0 + 0.1 * k0, 0.5 - 0.05 * k1])
u_seq = [0.0, 1.0, 1.0, -1.0]
d_seq = [
    h_true_2[0] + 0.10,
    h_true_2[0] + h_true_2[1] - 0.10,
    -h_true_2[0] + h_true_2[1] - 0.10,
]

h_hat = np.zeros(2)    # Initial h_hat(1|Y_0)
K_pred = np.eye(2)     # Initial K(1,0) = Pi_0
hand_b = []

print("\n--- Question b) Console Verification (n = 1, 2, 3) ---")
for n in range(1, 4):
    u_n = np.array([u_seq[n], u_seq[n-1]])
    d_n = d_seq[n-1]
    C_n = u_n.reshape(1, 2)
    alpha_n = float(d_n - u_n @ h_hat)
    R_n = float(u_n @ K_pred @ u_n + Q2_ex3)
    G_n = (K_pred @ u_n) / R_n
    h_hat = h_hat + G_n * alpha_n
    K_filt = K_pred - np.outer(G_n, u_n @ K_pred)
    K_filt = 0.5 * (K_filt + K_filt.T)
    K_pred = K_filt.copy()  # Q1=0 and F=I
    item = {
        "n": n, "C": u_n.tolist(), "d": float(d_n),
        "alpha": alpha_n, "R": R_n, "G": G_n.tolist(),
        "h": h_hat.tolist(), "K_filt": K_filt.tolist(),
        "K_pred_next": K_pred.tolist(), "trace_K": float(np.trace(K_filt)),
    }
    hand_b.append(item)
    print(f"n={n}: C={u_n}, d={d_n:.8f}, alpha={alpha_n:.8f}, R={R_n:.8f}")
    print(f"    G={G_n}, h_hat(next)={h_hat}")
    print(f"    K_filt=\n{K_filt}\n    K_pred(next)=\n{K_pred}\n    tr(K)={np.trace(K_filt):.8f}")

# =========================================================================
# QUESTION c): M = 5 Simulation (Figures 1 & 2, N = 1000)
# =========================================================================
N_c = 1000
np.random.seed(Student_ID)  # DO NOT MODIFY: seed lock for Figures 1 & 2

u_white = np.random.randn(N_c + M)
sigma_w = np.sqrt(1.0 - 0.92**2)
w_noise = sigma_w * np.random.randn(N_c + M)
u_color = np.zeros(N_c + M)
for k in range(N_c + M):
    u_color[k] = (0.92 * u_color[k-1] if k > 0 else 0.0) + w_noise[k]

v_ex3 = np.sqrt(Q2_ex3) * np.random.randn(N_c)
v_ex4 = np.sqrt(Q2_ex4) * np.random.randn(N_c)
b_ex4 = np.sqrt(0.01) * np.random.randn(N_c, M)

U_white = input_vectors(u_white, N_c, M)
U_color = input_vectors(u_color, N_c, M)

true_const = np.tile(h0_5, (N_c, 1))
d_ex3_white = U_white @ h0_5 + v_ex3
d_ex3_color = U_color @ h0_5 + v_ex3
ex3_white = simulate_kalman(U_white, d_ex3_white, Q2_ex3, np.zeros((M, M)))
ex3_color = simulate_kalman(U_color, d_ex3_color, Q2_ex3, np.zeros((M, M)))

# h(1) = h0_5, h(n) = h(n-1) + b_ex4[n-2] for n >= 2
true_random = np.zeros((N_c, M))
true_random[0] = h0_5
for idx in range(1, N_c):
    true_random[idx] = true_random[idx - 1] + b_ex4[idx - 1]

d_ex4_white = np.einsum("ij,ij->i", U_white, true_random) + v_ex4
d_ex4_color = np.einsum("ij,ij->i", U_color, true_random) + v_ex4
ex4_white = simulate_kalman(U_white, d_ex4_white, Q2_ex4, Q1_ex4)
ex4_color = simulate_kalman(U_color, d_ex4_color, Q2_ex4, Q1_ex4)

n_c = np.arange(1, N_c + 1)
peak_idx = int(np.argmax(np.abs(ex3_color["h_hat"][:, 2])))
peak_n = peak_idx + 1
peak_signed = float(ex3_color["h_hat"][peak_idx, 2])
peak_magnitude = float(abs(peak_signed))

fig, axes = plt.subplots(2, 1, figsize=(13.4, 8.7), sharex=True)
for ax, result, name in [(axes[0], ex3_white, "White input"),
                         (axes[1], ex3_color, "Colored AR(1) input")]:
    for j in range(M):
        ax.plot(n_c, result["h_hat"][:, j], color=COLORS[j], label=f"$\\hat{{h}}_{j}$")
        ax.axhline(h0_5[j], color=COLORS[j], ls=":", lw=0.9, alpha=0.45)
    ax.set_ylabel("Estimated weight")
    ax.set_title(name, loc="left")
    ax.grid(alpha=0.23)
axes[0].legend(loc="upper right", ncol=5, fontsize=8)
axes[1].scatter([peak_n], [peak_signed], s=58, color="black", zorder=6)
axes[1].annotate(f"max |h2| = {peak_magnitude:.5f} at n={peak_n}",
                 xy=(peak_n, peak_signed), xytext=(0.33, 0.92),
                 textcoords="axes fraction",
                 arrowprops=dict(arrowstyle="->", lw=1.2), fontsize=9)
axes[1].set_xlabel("Cycle n")
fig.suptitle(f"Figure 1: Example 3 weight convergence — {Student_Name} (ID: {Student_ID})")
fig.tight_layout(rect=(0, 0, 1, 0.95))
save_figure(fig, 1)

fig, axes = plt.subplots(2, 2, figsize=(13.4, 8.2), sharex=True)
for col, (result, name) in enumerate([(ex4_white, "White input"),
                                      (ex4_color, "Colored AR(1) input")]):
    for row, j in enumerate([0, 4]):
        ax = axes[row, col]
        ax.plot(n_c, true_random[:, j], color="#222222", lw=1.4, label="True")
        ax.plot(n_c, result["h_hat"][:, j], color=COLORS[j], lw=1.05,
                label="Kalman estimate")
        ax.set_title(f"{name} — tap {j+1}")
        ax.grid(alpha=0.2)
        if col == 0:
            ax.set_ylabel("Weight value")
        if row == 1:
            ax.set_xlabel("Cycle n")
        if row == 0:
            ax.legend(loc="best", fontsize=8)
fig.suptitle(f"Figure 2: Example 4 true vs. estimated tracking — {Student_Name} (ID: {Student_ID})")
fig.tight_layout(rect=(0, 0, 1, 0.94))
save_figure(fig, 2)

# =========================================================================
# QUESTIONS d) & e): Sudden System Change at n = 1001 (Figures 3 & 4)
# =========================================================================
N_de = 1500
np.random.seed(Student_ID)  # DO NOT MODIFY: seed lock for Figures 3 & 4

u_de = np.random.randn(N_de + M)
v_de = np.sqrt(Q2_ex3) * np.random.randn(N_de)
h_new_5 = h0_5 + np.array([1.0, -1.0, 0.5, -0.5, 0.8])
U_de = input_vectors(u_de, N_de, M)
true_step = np.tile(h0_5, (N_de, 1))
true_step[1000:, :] = h_new_5  # Python index 1000 = cycle n=1001
d_de = np.einsum("ij,ij->i", U_de, true_step) + v_de

std_ex3 = simulate_kalman(U_de, d_de, Q2_ex3, np.zeros((M, M)))
track_ex4 = simulate_kalman(U_de, d_de, Q2_ex3, Q1_ex4)
adapt_ex3 = simulate_kalman(U_de, d_de, Q2_ex3, np.zeros((M, M)), adaptive=True)

# First post-change cycle n>1001 at which 10 consecutive samples meet the bound.
inside_ex4 = abs(track_ex4["alpha"]) <= 2.0 * np.sqrt(track_ex4["R_pre"])
settle_idx = next((i for i in range(1001, N_de - 9)
                   if np.all(inside_ex4[i : i + 10])), None)
settle_start = settle_idx + 1 if settle_idx is not None else None
settle_confirmed = settle_idx + 10 if settle_idx is not None else None
settle_after = settle_start - 1001 if settle_start is not None else None

n_de = np.arange(1, N_de + 1)
fig, axes = plt.subplots(2, 1, figsize=(13.4, 9.3), sharex=True,
                         gridspec_kw={"height_ratios": [1.2, 1]})
weight_comparison(axes[0], n_de, true_step,
                  [("Example 3 (Q1=0)", std_ex3["h_hat"], "--"),
                   ("Example 4 (Q1=.01I)", track_ex4["h_hat"], "-")])
axes[0].set_title("5-tap trajectories: sudden system change at n=1001", loc="left")
axes[1].plot(n_de, std_ex3["alpha"], color="#235789", lw=0.85, alpha=0.62,
             label="Innovation, Example 3")
axes[1].plot(n_de, track_ex4["alpha"], color="#e07a20", lw=0.9, alpha=0.75,
             label="Innovation, Example 4")
for result, col, label in [(std_ex3, "#235789", "Ex3 +/-2 sqrt(R)"),
                           (track_ex4, "#e07a20", "Ex4 +/-2 sqrt(R)")]:
    bound = 2.0 * np.sqrt(result["R_pre"])
    axes[1].plot(n_de, bound, color=col, ls="--", lw=1.0, label=label)
    axes[1].plot(n_de, -bound, color=col, ls="--", lw=1.0)
axes[1].set_ylabel("Innovation / bounds")
axes[1].set_xlabel("Cycle n")
axes[1].legend(loc="upper right", fontsize=8, ncol=2)
for ax in axes:
    add_event_line(ax)
fig.suptitle(f"Figure 3: Lock-up vs. tracking — {Student_Name} (ID: {Student_ID})")
fig.tight_layout(rect=(0, 0, 1, 0.95))
save_figure(fig, 3)

fig, axes = plt.subplots(3, 1, figsize=(13.4, 11.0), sharex=True,
                         gridspec_kw={"height_ratios": [1.2, 1, 0.8]})
weight_comparison(axes[0], n_de, true_step,
                  [("Standard Example 3", std_ex3["h_hat"], "--"),
                   ("Adaptive reset", adapt_ex3["h_hat"], "-")])
axes[0].set_title("5-tap estimates: standard vs. adaptive", loc="left")
pre_band = 2.0 * np.sqrt(adapt_ex3["R_pre"])
axes[1].plot(n_de, adapt_ex3["alpha"], color="#235789", lw=0.9,
             label="Innovation (before reset)")
axes[1].plot(n_de, pre_band, color="#bf4c37", ls="--", lw=1.1,
             label="+/- 2 sqrt(R_pre)")
axes[1].plot(n_de, -pre_band, color="#bf4c37", ls="--", lw=1.1)
axes[1].set_ylabel("Innovation / bounds")
axes[1].legend(loc="upper right", fontsize=8)
axes[2].plot(n_de, std_ex3["trace_prior"], color="#666666", ls="--", lw=1.0,
             label="Standard tr(P)")
axes[2].plot(n_de, adapt_ex3["trace_prior"], color="#226b9a", lw=0.9,
             label="Adaptive tr(P) after reset decision")
axes[2].axhline(M, color="#bf4c37", ls=":", lw=1.1, label="tr(I5)=5")
axes[2].set_ylabel("Predicted tr(P)")
axes[2].set_xlabel("Cycle n")
axes[2].legend(loc="upper right", fontsize=8, ncol=2)
for ax in axes:
    add_event_line(ax)
fig.suptitle(f"Figure 4: Innovation-triggered covariance resets — {Student_Name} (ID: {Student_ID})")
fig.tight_layout(rect=(0, 0, 1, 0.955))
save_figure(fig, 4)

# -------------------------------------------------------------------------
# QUESTION e): Analytical 2-tap reset check at n=1001 and n=1002
# -------------------------------------------------------------------------
# This short deterministic calculation verifies the hand-worked result.
P_hand = np.zeros((2, 2))  # Exact gain lock-up before the abrupt change
h_hand = h_true_2.copy()
h_new_2 = h_true_2 + np.array([1.0, -1.0])
hand_e = []
for n, u, d in [
    (1001, np.array([1.0, -1.0]), float(h_new_2 @ [1.0, -1.0])),
    (1002, np.array([1.0, 1.0]), float(h_new_2 @ [1.0, 1.0] + 0.05)),
]:
    alpha = float(d - u @ h_hand)
    r_pre = float(u @ P_hand @ u + Q2_ex3)
    did_reset = abs(alpha) > 2.0 * np.sqrt(r_pre)
    if did_reset:
        P_hand = np.eye(2)
    r_post = float(u @ P_hand @ u + Q2_ex3)
    gain = (P_hand @ u) / r_post
    h_hand = h_hand + gain * alpha
    P_hand = P_hand - np.outer(gain, u @ P_hand)
    P_hand = 0.5 * (P_hand + P_hand.T)
    hand_e.append({
        "n": n, "C": u.tolist(), "d": d, "alpha": alpha,
        "R_pre": r_pre, "R_post": r_post, "reset": bool(did_reset),
        "G": gain.tolist(), "h": h_hand.tolist(),
        "K_pred_next": P_hand.tolist(),
    })

print("\n--- Question e) 2-tap deterministic reset verification ---")
for row in hand_e:
    print(f"n={row['n']}: alpha={row['alpha']:.12f}, "
          f"R_pre={row['R_pre']:.12f}, R_post={row['R_post']:.12f}, "
          f"reset={row['reset']}, G={row['G']}, h={row['h']}")
    print(f"    K_pred(next)={np.array(row['K_pred_next'])}")

# =========================================================================
# QUESTION f): Non-Gaussian Uniform White Noise (Figure 5)
# =========================================================================
np.random.seed(Student_ID)  # DO NOT MODIFY: seed lock for Figure 5

u_f = np.random.randn(N_de + M)
v_uniform = np.sqrt(3.0 * Q2_ex3) * (2.0 * np.random.rand(N_de) - 1.0)
U_f = input_vectors(u_f, N_de, M)
d_f = np.einsum("ij,ij->i", U_f, true_step) + v_uniform
adapt_uniform = simulate_kalman(U_f, d_f, Q2_ex3,
                                np.zeros((M, M)), adaptive=True)

bound_75 = 2.0 * np.sqrt(adapt_uniform["R_pre"])
bound_95 = np.sqrt(20.0) * np.sqrt(adapt_uniform["R_pre"])
inside75 = np.abs(adapt_uniform["alpha"]) <= bound_75
inside95 = np.abs(adapt_uniform["alpha"]) <= bound_95
count75 = int(np.count_nonzero(inside75))
count95 = int(np.count_nonzero(inside95))
rate75 = float(100.0 * count75 / N_de)
rate95 = float(100.0 * count95 / N_de)

fig, ax = plt.subplots(figsize=(13.4, 6.3))
ax.plot(n_de, adapt_uniform["alpha"], lw=0.8, color="#235789",
        label="Innovation alpha(n)")
ax.plot(n_de, bound_75, color="#e07a20", ls="--", lw=1.25,
        label="Chebyshev 75%: +/- 2 sqrt(R_pre)")
ax.plot(n_de, -bound_75, color="#e07a20", ls="--", lw=1.25)
ax.plot(n_de, bound_95, color="#299a70", ls="-.", lw=1.25,
        label="Chebyshev 95%: +/- sqrt(20) sqrt(R_pre)")
ax.plot(n_de, -bound_95, color="#299a70", ls="-.", lw=1.25)
ax.text(0.02, 0.97, f"Inside 75% bound: {count75}/{N_de} = {rate75:.2f}%\n"
        f"Inside 95% bound: {count95}/{N_de} = {rate95:.2f}%",
        transform=ax.transAxes, va="top", ha="left", fontsize=10,
        bbox={"facecolor": "white", "alpha": 0.88, "edgecolor": "#bbbbbb"})
ax.set_xlabel("Cycle n")
ax.set_ylabel("Innovation / Chebyshev bounds")
ax.legend(loc="upper right", fontsize=8)
add_event_line(ax)
fig.suptitle(f"Figure 5: Uniform-noise innovation bounds — {Student_Name} (ID: {Student_ID})")
fig.tight_layout(rect=(0, 0, 1, 0.94))
save_figure(fig, 5)

# =========================================================================
# NUMERICAL EXTRACTION REPORT FOR QUESTIONS c), d), AND f)
# =========================================================================
# For c): peak is defined as the sample with maximal ABSOLUTE h_hat[2].
# For d): first START n>1001 of a 10-consecutive-in-bound sequence.
# For f): compare every innovation with R_pre (computed BEFORE any reset).
kp_ex4 = (5.0 * 0.01 + np.sqrt((5.0 * 0.01)**2 + 4.0 * 0.01 * Q2_ex4)) / 2.0
kf_ex4 = kp_ex4 - 0.01
r_ss_ex4 = 5.0 * kp_ex4 + Q2_ex4
gp_ex4 = 5.0 * kp_ex4 / r_ss_ex4

report = {
    "name": Student_Name, "id": Student_ID,
    "k0": k0, "k1": k1, "k2": k2,
    "h0_5": h0_5.tolist(), "h_true_2": h_true_2.tolist(),
    "h_new_5": h_new_5.tolist(),
    "Q2_ex3": Q2_ex3, "Q2_ex4": Q2_ex4,
    "b": hand_b,
    "e_two_tap": hand_e,
    "c": {
        "peak_n": peak_n,
        "peak_h2_signed": peak_signed,
        "peak_abs_h2": peak_magnitude,
        "overshoot_beyond_abs_true": peak_magnitude - 1.0,
        "ss_kp_ex4": kp_ex4,
        "ss_kf_ex4": kf_ex4,
        "ss_R_ex4": r_ss_ex4,
        "ss_gp_ex4": gp_ex4,
    },
    "d": {
        "settle_start_n": settle_start,
        "settle_confirmed_n": settle_confirmed,
        "cycles_after_n1001": settle_after,
        "adaptive_reset_at_1001": bool(adapt_ex3["resets"][1000]),
        "adaptive_trace_at_1001": float(adapt_ex3["trace_prior"][1000]),
        "reset_count_total": int(np.count_nonzero(adapt_ex3["resets"])),
        "reset_cycles_first_25": (np.where(adapt_ex3["resets"])[0][:25] + 1).tolist(),
    },
    "f": {
        "count75": count75, "count95": count95,
        "rate75_percent": rate75, "rate95_percent": rate95,
        "total": N_de,
        "resets": int(np.count_nonzero(adapt_uniform["resets"])),
    },
    "implementation": {
        "first_regressor_indices": "M-1..0, i.e. first sample starts at cycle n=1",
        "ex4_random_walk": "h_true[0]=h0_5, then h_true[i]=h_true[i-1]+b_ex4[i-1]",
        "threshold_convention": "2 sqrt(R_pre) before reset; after trigger recompute R_used and G",
        "simulation_variance_d_e_f": Q2_ex3,
    },
}
(OUTPUT_DIR / "numerical_results.json").write_text(
    json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
)

print("\n--- Question c) White input steady state ---")
print(f"Ex3: Kpred=Kfilt=0, G=0, R={Q2_ex3:.10f}")
print(f"Ex4: kp={kp_ex4:.10f}, kf={kf_ex4:.10f}, R={r_ss_ex4:.10f}, gp={gp_ex4:.10f}")
print("\n--- Requested Numerical Extraction ---")
print(f"c / Fig1 / colored: peak h_hat[2]={peak_signed:.12f}, "
      f"abs peak={peak_magnitude:.12f}, n_max={peak_n}")
print(f"d / Fig3 / Example4: first 10-cycle run starts at n={settle_start}, "
      f"confirmed at n={settle_confirmed}, starts {settle_after} cycles after 1001")
print(f"e / Fig4: reset at n=1001? {report['d']['adaptive_reset_at_1001']}, "
      f"trace at n=1001={report['d']['adaptive_trace_at_1001']:.6f}, "
      f"all resets={report['d']['reset_count_total']}")
print(f"f / Fig5: 75%: {count75}/{N_de}={rate75:.8f}% ; "
      f"95%: {count95}/{N_de}={rate95:.8f}%")
