# -*- coding: utf-8 -*-
"""Kalman homework - Pham Hoang Le, ID 2670142.

Requires: numpy, matplotlib. Run: python SSP_2670142.py
The random draws and seed locations follow python_starter_template.pdf.
Cycle n=i+1 uses input_array[i:i+M][::-1]; the first M-1 samples
are the FIR prehistory. Plotted weights are posterior estimates at cycle n.
For Example 4, h_true(1)=h0 and b[i] generates h_true(n+1).
"""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

Student_Name = 'Phạm Hoàng Lê'
Student_ID = 2670142
k0 = Student_ID % 10
k1 = (Student_ID // 10) % 10
k2 = (Student_ID // 100) % 10
M = 5
h0_5 = np.array([1.0 + .1*k0, .5, -1.0, .3, -.4-.05*k1])
Q2_ex3 = .10 + .02*k2
Q2_ex4 = 1.0 + .1*k2
Q1_ex4 = .01*np.eye(M)
h_new_5 = h0_5 + np.array([1., -1., .5, -.5, .8])


def input_matrix(samples, N, offset=0):
    """Rows are u(n)^T, n=1,...,N. Offset 0 is the reported convention."""
    return np.array([samples[i+offset:i+offset+M][::-1] for i in range(N)])


def kalman(U, H, noise, q2, q=0.0, reset=False):
    N, m = U.shape
    estimate = np.zeros(m)
    P = np.eye(m)
    I = np.eye(m)
    out = {key: np.zeros(N) for key in ['alpha', 'R_pre', 'R_used',
           'trace_pre', 'trace_used', 'min_eigenvalue']}
    out['h'] = np.zeros((N, m))
    out['gain'] = np.zeros((N, m))
    out['reset'] = np.zeros(N, dtype=bool)
    for i, u in enumerate(U):
        alpha = float(u @ H[i] + noise[i] - u @ estimate)
        R_pre = float(u @ P @ u + q2)
        out['trace_pre'][i] = np.trace(P)
        if reset and abs(alpha) > 2*np.sqrt(R_pre):
            P = I.copy()
            out['reset'][i] = True
        R = float(u @ P @ u + q2)
        G = P @ u / R
        estimate = estimate + G*alpha
        # Joseph form is algebraically identical to P - P u u^T P / R.
        A = I - np.outer(G, u)
        Pf = A @ P @ A.T + q2*np.outer(G, G)
        Pf = .5*(Pf+Pf.T)
        out['h'][i] = estimate
        out['gain'][i] = G
        out['alpha'][i] = alpha
        out['R_pre'][i] = R_pre
        out['R_used'][i] = R
        out['trace_used'][i] = np.trace(P)
        out['min_eigenvalue'][i] = np.linalg.eigvalsh(Pf)[0]
        P = Pf + q*I
    assert np.all(out['R_pre'] > 0)
    assert np.min(out['min_eigenvalue']) > -1e-10
    return out


def simulate(offset=0):
    # Question c: preserve the exact draw order of the starter template.
    N_c = 1000
    np.random.seed(Student_ID)
    u_white = np.random.randn(N_c + M)
    sigma_w = np.sqrt(1.0 - .92**2)
    w_noise = sigma_w*np.random.randn(N_c + M)
    u_color = np.zeros(N_c + M)
    for k in range(N_c + M):
        u_color[k] = (.92*u_color[k-1] if k > 0 else 0.0) + w_noise[k]
    v_ex3 = np.sqrt(Q2_ex3)*np.random.randn(N_c)
    v_ex4 = np.sqrt(Q2_ex4)*np.random.randn(N_c)
    b_ex4 = np.sqrt(.01)*np.random.randn(N_c, M)
    H3 = np.tile(h0_5, (N_c, 1))
    H4 = H3.copy()
    H4[1:] += np.cumsum(b_ex4[:-1], axis=0)
    Uw, Uc = input_matrix(u_white, N_c, offset), input_matrix(u_color, N_c, offset)
    c3w = kalman(Uw, H3, v_ex3, Q2_ex3)
    c3c = kalman(Uc, H3, v_ex3, Q2_ex3)
    c4w = kalman(Uw, H4, v_ex4, Q2_ex4, q=.01)
    c4c = kalman(Uc, H4, v_ex4, Q2_ex4, q=.01)
    # Questions d and e: exactly one seed reset for this shared block.
    N_de = 1500
    np.random.seed(Student_ID)
    u_de = np.random.randn(N_de + M)
    v_de = np.sqrt(Q2_ex3)*np.random.randn(N_de)
    Ude = input_matrix(u_de, N_de, offset)
    Hde = np.tile(h0_5, (N_de, 1))
    Hde[1000:] = h_new_5
    standard = kalman(Ude, Hde, v_de, Q2_ex3)
    tracking = kalman(Ude, Hde, v_de, Q2_ex3, q=.01)
    adaptive = kalman(Ude, Hde, v_de, Q2_ex3, reset=True)
    # Question f: preserve seed, Gaussian input, then uniform output noise.
    np.random.seed(Student_ID)
    u_f = np.random.randn(N_de + M)
    v_uniform = np.sqrt(3.0*Q2_ex3)*(2.0*np.random.rand(N_de)-1.0)
    uniform = kalman(input_matrix(u_f, N_de, offset), Hde,
                     v_uniform, Q2_ex3, reset=True)
    return dict(c3w=c3w,c3c=c3c,c4w=c4w,c4c=c4c,H4=H4,
                standard=standard,tracking=tracking,adaptive=adaptive,
                uniform=uniform,Hde=Hde,Ude=Ude,v_de=v_de)


def extract_metrics(data):
    peak_i = int(np.argmax(np.abs(data['c3c']['h'][:,2])))
    t = data['tracking']
    inside = np.abs(t['alpha']) <= 2*np.sqrt(t['R_pre'])
    # i=1001 is cycle n=1002, enforcing n > 1001.
    first = next((i for i in range(1001,len(inside)-9)
                  if np.all(inside[i:i+10])), None)
    f = data['uniform']
    counts = [int(np.count_nonzero(np.abs(f['alpha']) <= z*np.sqrt(f['R_pre'])))
              for z in [2.,np.sqrt(20.)]]
    a = data['adaptive']
    window = (np.flatnonzero(a['reset']) + 1)
    post_resets = window[window >= 1001]
    return dict(Student_Name=Student_Name,Student_ID=Student_ID,
        k0=k0,k1=k1,k2=k2,input_offset=0,
        c_peak_signed=float(data['c3c']['h'][peak_i,2]),
        c_peak_absolute=float(abs(data['c3c']['h'][peak_i,2])),
        c_peak_cycle=peak_i+1,
        d_first_10_start=None if first is None else first+1,
        d_first_10_end=None if first is None else first+10,
        d_delay_to_start=None if first is None else first+1-1001,
        d_delay_to_confirmation=None if first is None else first+10-1001,
        f_count_2sigma=counts[0],f_percent_2sigma=100*counts[0]/1500,
        f_count_sqrt20=counts[1],f_percent_sqrt20=100*counts[1]/1500,
        adaptive_reset_at_1001=bool(a['reset'][1000]),
        adaptive_R_pre_1001=float(a['R_pre'][1000]),
        adaptive_alpha_1001=float(a['alpha'][1000]),
        adaptive_trace_used_1001=float(a['trace_used'][1000]),
        adaptive_total_resets=int(a['reset'].sum()),
        adaptive_first_postchange_reset=int(post_resets[0]) if len(post_resets) else None,
        adaptive_resets_980_1040=window[(window>=980)&(window<=1040)].tolist(),
        uniform_total_resets=int(f['reset'].sum()),
        standard_final_weights=data['standard']['h'][-1].tolist(),
        tracking_final_weights=data['tracking']['h'][-1].tolist(),
        adaptive_final_weights=a['h'][-1].tolist())


def configure_plots():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,
        'axes.grid':True,'grid.alpha':.18,'axes.spines.top':False,
        'axes.spines.right':False,'savefig.dpi':190,'lines.linewidth':1.1})


def finish(fig, num, title, outdir):
    fig.suptitle(f'Hình {num}. {title}\n{Student_Name} - MSSV {Student_ID}',
                 fontsize=14,fontweight='bold')
    fig.savefig(outdir/f'Figure_{num}.png',facecolor='white')
    plt.close(fig)


def weight_legend(ax, styles):
    colors = plt.rcParams['axes.prop_cycle'].by_key()['color'][:M]
    handles = [Line2D([],[],color=colors[j],label=f'h{j}') for j in range(M)]
    handles += [Line2D([],[],color='black',
                linestyle='-' if 'nhạt' in label else s,
                alpha=.3 if 'nhạt' in label else 1.,
                linewidth=2.3 if 'nhạt' in label else 1.1,label=label)
                for s,label in styles]
    ax.legend(handles=handles,ncol=4,loc='best',fontsize=8)


def plot_all(d, outdir):
    configure_plots()
    colors = plt.rcParams['axes.prop_cycle'].by_key()['color'][:M]
    n = np.arange(1,1001)
    fig,axs=plt.subplots(2,1,figsize=(12,8),layout='constrained',sharex=True)
    for ax,key,title in zip(axs,['c3w','c3c'],['Đầu vào trắng','Đầu vào màu AR(1), hệ số 0.92']):
        for j in range(M):
            ax.plot(n,d[key]['h'][:,j],color=colors[j],label=f'h{j}')
            ax.axhline(h0_5[j],color=colors[j],ls=':',alpha=.6,lw=1)
        ax.set(title=title,ylabel='Hệ số ước lượng')
        ax.legend(ncol=5,fontsize=8)
    p=int(np.argmax(np.abs(d['c3c']['h'][:,2])))
    axs[1].plot(p+1,d['c3c']['h'][p,2],'ko',ms=4)
    axs[1].annotate(f'n={p+1}; h2={d["c3c"]["h"][p,2]:.9f}',
        xy=(p+1,d['c3c']['h'][p,2]),xytext=(100,-.3),
        arrowprops={'arrowstyle':'->','lw':.8},fontsize=9)
    axs[-1].set_xlabel('Chu kỳ n')
    finish(fig,1,'Hội tụ nhận dạng hệ FIR 5 hệ số (Example 3)',outdir)
    fig,axs=plt.subplots(2,2,figsize=(12,8),layout='constrained',sharex=True)
    for col,(key,label) in enumerate([('c4w','Đầu vào trắng'),('c4c','Đầu vào màu')]):
        for row,j in enumerate([0,4]):
            ax=axs[row,col]
            ax.plot(n,d['H4'][:,j],color='#202b39',label='Hệ số thật',lw=1.2)
            ax.plot(n,d[key]['h'][:,j],color='#d97706',label='Kalman',lw=1.0)
            ax.set(title=f'{label} - hệ số #{j+1} (h{j})',ylabel='Giá trị hệ số')
            ax.legend(fontsize=8)
            if row==1: ax.set_xlabel('Chu kỳ n')
    finish(fig,2,'Bám hệ biến thiên theo random walk (Example 4)',outdir)
    n=np.arange(1,1501)
    fig,axs=plt.subplots(2,1,figsize=(12,9),layout='constrained',sharex=True,
                         gridspec_kw={'height_ratios':[1.25,1.]})
    for j in range(M):
        axs[0].plot(n,d['Hde'][:,j],color=colors[j],lw=2.3,alpha=.3)
        axs[0].plot(n,d['standard']['h'][:,j],color=colors[j],ls='--',lw=1)
        axs[0].plot(n,d['tracking']['h'][:,j],color=colors[j],lw=1)
    axs[0].set(ylabel='Hệ số',title='Cùng nhiễu đo Q2=0.12; đổi hệ tại n=1001')
    weight_legend(axs[0],[('--','Chuẩn Q1=0'),('-','Bám Q1=0.01 I'),(':','Giá trị thật: nét nhạt')])
    for key,color,label in [('standard','#b45309','Chuẩn'),('tracking','#1d4ed8','Bám')]:
        z=d[key]
        axs[1].plot(n,z['alpha'],color=color,lw=.65,alpha=.8,label=f'Innovation - {label}')
        bound=2*np.sqrt(z['R_pre'])
        axs[1].plot(n,bound,color=color,ls='--',lw=.7,label=f'±2√R - {label}')
        axs[1].plot(n,-bound,color=color,ls='--',lw=.7)
    axs[1].legend(ncol=2,fontsize=8)
    axs[1].set(ylabel='Innovation α(n)',xlabel='Chu kỳ n')
    for ax in axs: ax.axvline(1001,color='black',ls=':',lw=1)
    finish(fig,3,'Đổi hệ đột ngột: Kalman chuẩn và Kalman có nhiễu quá trình',outdir)
    fig,axs=plt.subplots(3,1,figsize=(12,11),layout='constrained',sharex=True,
                         gridspec_kw={'height_ratios':[1.3,1.,.7]})
    for j in range(M):
        axs[0].plot(n,d['Hde'][:,j],color=colors[j],lw=2.3,alpha=.25)
        axs[0].plot(n,d['standard']['h'][:,j],color=colors[j],ls='--',lw=.8)
        axs[0].plot(n,d['adaptive']['h'][:,j],color=colors[j],lw=.9)
    weight_legend(axs[0],[('--','Chuẩn Q1=0'),('-','Reset thích nghi'),(':','Giá trị thật: nét nhạt')])
    axs[0].set(ylabel='Hệ số',title='Cơ chế reset được kiểm tra ở mọi chu kỳ')
    a=d['adaptive']; b=2*np.sqrt(a['R_pre'])
    axs[1].plot(n,a['alpha'],color='#1d4ed8',lw=.7,label='Innovation trước reset')
    axs[1].plot(n,b,color='#b45309',ls='--',lw=.8,label='±2√R trước reset')
    axs[1].plot(n,-b,color='#b45309',ls='--',lw=.8)
    axs[1].set_ylabel('Innovation α(n)'); axs[1].legend(fontsize=8)
    axs[2].plot(n,a['trace_pre'],color='#64748b',lw=.7,label='Trước kiểm tra reset')
    axs[2].plot(n,a['trace_used'],color='#dc2626',lw=.7,label='Sau reset, trước cập nhật')
    axs[2].axhline(5,color='#dc2626',ls=':',lw=.7)
    axs[2].set(ylabel='tr(K dự báo)',xlabel='Chu kỳ n')
    axs[2].legend(fontsize=8,ncol=2)
    for ax in axs: ax.axvline(1001,color='black',ls=':',lw=.9)
    finish(fig,4,'Nhận dạng với reset ma trận sai số theo innovation',outdir)
    f=d['uniform']
    fig,(ax,axz)=plt.subplots(2,1,figsize=(12,8),layout='constrained',sharex=True,
                             gridspec_kw={'height_ratios':[1.,1.]})
    ax.plot(n,f['alpha'],color='#1d4ed8',lw=.75,label='Innovation, nhiễu đo đều')
    for scale,color,label in [(2.,'#d97706','±2√R: Chebyshev ≥75%'),
                              (np.sqrt(20.),'#7c3aed','±√20 √R: Chebyshev ≥95%')]:
        b=scale*np.sqrt(f['R_pre'])
        ax.plot(n,b,color=color,lw=.8,ls='--',label=label)
        ax.plot(n,-b,color=color,lw=.8,ls='--')
    ax.axvline(1001,color='black',ls=':',lw=1)
    ax.set(xlabel='Chu kỳ n',ylabel='Innovation α(n)',title='R luôn được lưu trước kiểm tra reset')
    ax.legend(loc='upper right',fontsize=8)
    axz.plot(n,f['alpha']/np.sqrt(f['R_pre']),color='#1d4ed8',lw=.8,label='z(n) = α(n) / √R trước reset')
    for z,color in [(2.,'#d97706'),(np.sqrt(20.),'#7c3aed')]:
        axz.axhline(z,color=color,ls='--',lw=.8)
        axz.axhline(-z,color=color,ls='--',lw=.8)
    axz.axvline(1001,color='black',ls=':',lw=1)
    axz.set(ylabel='Innovation chuẩn hóa z(n)',xlabel='Chu kỳ n',title='Cùng dữ liệu sau chuẩn hóa: so sánh trực tiếp các ngưỡng 2 và √20')
    axz.legend(fontsize=8)
    finish(fig,5,'Nhiễu không Gaussian và các ngưỡng Chebyshev',outdir)


def verify_hand():
    # Independent information-form check of all three cycles in question b.
    h=np.zeros(2); P=np.eye(2); X=[]; ys=[]; rows=[]
    for n,(u,y) in enumerate(zip([[1.,0.],[1.,1.],[-1.,1.]],[1.3,1.4,-1.0]),1):
        u=np.array(u); alpha=y-u@h; R=u@P@u+Q2_ex3; G=P@u/R
        h=h+G*alpha; P=P-np.outer(P@u,P@u)/R
        X.append(u); ys.append(y); A=np.array(X)
        refP=np.linalg.inv(np.eye(2)+A.T@A/Q2_ex3)
        refh=refP@A.T@np.array(ys)/Q2_ex3
        assert np.allclose(P,refP) and np.allclose(h,refh)
        rows.append(dict(n=n,C=u.tolist(),alpha=float(alpha),R=float(R),
                         G=G.tolist(),h=h.tolist(),K=P.tolist(),trace=float(np.trace(P))))
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    d=simulate(); m=extract_metrics(d); m['question_b']=verify_hand()
    kp=(M*.01+np.sqrt((M*.01)**2+4*.01*Q2_ex4))/2
    m['steady_state_approximation']=dict(kp=float(kp),kf=float(kp-.01),
        R=float(M*kp+Q2_ex4),gp=float(M*kp/(M*kp+Q2_ex4)))
    plot_all(d,args.output_dir)
    (args.output_dir/'ket_qua_2670142.json').write_text(
        json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(m,ensure_ascii=False,indent=2))
    print('Saved Figure_1.png through Figure_5.png.')


if __name__=='__main__':
    main()
